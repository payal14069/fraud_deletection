"""
01_generate_data.py
--------------------
Generates a realistic synthetic dataset for an online payment platform,
with deliberately embedded fraud patterns so downstream detection rules
have real signal to catch:

  - Fake / duplicate accounts sharing device & IP fingerprints
  - Disposable email domains
  - Bonus abuse rings (many accounts farming signup bonuses on shared devices)
  - Referral fraud (self-referrals / referral rings)
  - Suspicious transactions (odd hours, high velocity, high amounts,
    new-account-cash-out patterns)

Output CSVs are written to ../data/
"""

import numpy as np
import pandas as pd
from faker import Faker
import random
import uuid
from datetime import datetime, timedelta

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
fake = Faker()
Faker.seed(SEED)

N_USERS = 5000
N_LEGIT_RING_CLUSTERS = 40          # clusters of fake accounts sharing device/IP
RING_SIZE_RANGE = (3, 9)
N_TRANSACTIONS = 25000
START_DATE = datetime(2026, 1, 1)
END_DATE = datetime(2026, 8, 1)

DISPOSABLE_DOMAINS = ["mailinator.com", "10minutemail.com", "tempmail.com",
                       "guerrillamail.com", "yopmail.com", "trashmail.com"]
NORMAL_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "proton.me"]

DEVICE_POOL = [f"DEV-{uuid.uuid4().hex[:10]}" for _ in range(int(N_USERS * 0.85))]
IP_POOL = [fake.ipv4() for _ in range(int(N_USERS * 0.8))]

def random_datetime(start, end):
    delta = end - start
    return start + timedelta(seconds=random.randint(0, int(delta.total_seconds())))

# ------------------------------------------------------------------
# 1. USERS
# ------------------------------------------------------------------
users = []
ring_user_ids = set()

# --- Legit organic users ---
n_organic = N_USERS - sum(range(*RING_SIZE_RANGE)) * 0  # placeholder, adjust below

user_id_counter = 1

def new_user(device, ip, email_domain, signup_date, is_ring=False, ring_id=None, kyc_verified=None):
    global user_id_counter
    uid = f"U{user_id_counter:06d}"
    user_id_counter += 1
    name = fake.name()
    email_user = name.lower().replace(" ", ".") + str(random.randint(1, 999))
    kyc = kyc_verified if kyc_verified is not None else (random.random() > 0.08)
    rec = {
        "user_id": uid,
        "name": name,
        "email": f"{email_user}@{email_domain}",
        "phone": fake.msisdn()[:10],
        "signup_date": signup_date.strftime("%Y-%m-%d %H:%M:%S"),
        "device_id": device,
        "signup_ip": ip,
        "kyc_verified": kyc,
        "country": fake.country_code(),
        "is_synthetic_fraud_ring": is_ring,
        "ring_id": ring_id if ring_id else "",
    }
    users.append(rec)
    return uid

# Fraud rings: clusters of accounts sharing device/IP, disposable emails, rapid signups
ring_id_counter = 1
for _ in range(N_LEGIT_RING_CLUSTERS):
    ring_size = random.randint(*RING_SIZE_RANGE)
    shared_device = f"DEV-{uuid.uuid4().hex[:10]}"
    shared_ip = fake.ipv4()
    ring_id = f"RING-{ring_id_counter:03d}"
    ring_id_counter += 1
    base_time = random_datetime(START_DATE, END_DATE)
    for i in range(ring_size):
        # rings sign up within minutes of each other from same device/IP
        st = base_time + timedelta(minutes=random.randint(0, 45))
        domain = random.choice(DISPOSABLE_DOMAINS) if random.random() < 0.7 else random.choice(NORMAL_DOMAINS)
        uid = new_user(shared_device, shared_ip, domain, st, is_ring=True, ring_id=ring_id,
                        kyc_verified=(random.random() > 0.85))
        ring_user_ids.add(uid)

# Organic users
n_organic = N_USERS - len(users)
for _ in range(n_organic):
    device = random.choice(DEVICE_POOL)
    ip = random.choice(IP_POOL)
    domain = random.choice(NORMAL_DOMAINS) if random.random() > 0.03 else random.choice(DISPOSABLE_DOMAINS)
    st = random_datetime(START_DATE, END_DATE)
    new_user(device, ip, domain, st)

users_df = pd.DataFrame(users)

# ------------------------------------------------------------------
# 2. REFERRALS  (self-referral / referral-ring fraud embedded)
# ------------------------------------------------------------------
referrals = []
all_ids = users_df["user_id"].tolist()
ring_groups = users_df[users_df.is_synthetic_fraud_ring].groupby("ring_id")["user_id"].apply(list)

ref_id_counter = 1
# Ring members refer each other (referral farming)
for ring_id, members in ring_groups.items():
    if len(members) < 2:
        continue
    for i in range(len(members) - 1):
        referrals.append({
            "referral_id": f"R{ref_id_counter:06d}",
            "referrer_id": members[i],
            "referee_id": members[i + 1],
            "referral_date": users_df.loc[users_df.user_id == members[i + 1], "signup_date"].values[0],
            "bonus_claimed": True,
            "bonus_amount": round(random.uniform(5, 25), 2),
        })
        ref_id_counter += 1

# Organic referrals (sparser, natural)
organic_users = users_df[~users_df.is_synthetic_fraud_ring]["user_id"].tolist()
for _ in range(600):
    referrer, referee = random.sample(organic_users, 2)
    referrals.append({
        "referral_id": f"R{ref_id_counter:06d}",
        "referrer_id": referrer,
        "referee_id": referee,
        "referral_date": users_df.loc[users_df.user_id == referee, "signup_date"].values[0],
        "bonus_claimed": random.random() > 0.2,
        "bonus_amount": round(random.uniform(5, 25), 2),
    })
    ref_id_counter += 1

referrals_df = pd.DataFrame(referrals)

# ------------------------------------------------------------------
# 3. BONUS CLAIMS (signup / promo bonus abuse embedded)
# ------------------------------------------------------------------
bonus_claims = []
bc_counter = 1
for _, row in users_df.iterrows():
    if random.random() < 0.9:  # most users claim a signup bonus
        amt = round(random.uniform(2, 15), 2)
        bonus_claims.append({
            "claim_id": f"B{bc_counter:06d}",
            "user_id": row.user_id,
            "device_id": row.device_id,
            "claim_type": "signup_bonus",
            "amount": amt,
            "claim_date": row.signup_date,
        })
        bc_counter += 1
    # ring members double-dip on promo bonuses
    if row.is_synthetic_fraud_ring and random.random() < 0.6:
        st = pd.to_datetime(row.signup_date) + timedelta(hours=random.randint(1, 48))
        bonus_claims.append({
            "claim_id": f"B{bc_counter:06d}",
            "user_id": row.user_id,
            "device_id": row.device_id,
            "claim_type": "promo_bonus",
            "amount": round(random.uniform(5, 30), 2),
            "claim_date": st.strftime("%Y-%m-%d %H:%M:%S"),
        })
        bc_counter += 1

bonus_df = pd.DataFrame(bonus_claims)

# ------------------------------------------------------------------
# 4. TRANSACTIONS
# ------------------------------------------------------------------
transactions = []
tx_counter = 1
merchants = [fake.company() for _ in range(300)]

def add_tx(user_id, device_id, ip, amount, tx_time, tx_type, merchant, status="success"):
    global tx_counter
    transactions.append({
        "transaction_id": f"T{tx_counter:07d}",
        "user_id": user_id,
        "device_id": device_id,
        "ip_address": ip,
        "amount": round(amount, 2),
        "transaction_time": tx_time.strftime("%Y-%m-%d %H:%M:%S"),
        "transaction_type": tx_type,
        "merchant": merchant,
        "status": status,
    })
    tx_counter += 1

users_indexed = users_df.set_index("user_id")

# Normal organic transaction behaviour
for uid in organic_users:
    urow = users_indexed.loc[uid]
    n_tx = np.random.poisson(4) + 1
    signup_dt = pd.to_datetime(urow.signup_date)
    for _ in range(n_tx):
        t = random_datetime(max(signup_dt, START_DATE), END_DATE)
        # normal hours weighted 8am-11pm
        hour = int(np.clip(np.random.normal(15, 4), 0, 23))
        t = t.replace(hour=hour)
        amt = np.random.lognormal(mean=3.2, sigma=0.8)  # typical purchase sizes
        add_tx(uid, urow.device_id, urow.signup_ip, amt, t,
               random.choice(["purchase", "transfer", "withdrawal"]),
               random.choice(merchants))

# Fraud ring transaction behaviour: rapid bursts, odd hours, cash-out pattern
for ring_id, members in ring_groups.items():
    burst_time = random_datetime(START_DATE, END_DATE)
    shared_ip = users_indexed.loc[members[0], "signup_ip"]
    for m in members:
        urow = users_indexed.loc[m]
        n_tx = np.random.poisson(6) + 2
        for i in range(n_tx):
            # rapid-fire transactions within a short burst window, odd hours
            t = burst_time + timedelta(minutes=random.randint(0, 90) + i * random.randint(1, 5))
            hour = random.choice([1, 2, 3, 4, 23])  # odd hours
            t = t.replace(hour=hour)
            amt = np.random.choice([
                np.random.uniform(500, 2000),   # high-value cash-out
                np.random.uniform(1, 20),       # micro-tx to test card/account
            ], p=[0.6, 0.4])
            add_tx(m, urow.device_id, urow.signup_ip, amt, t, "withdrawal",
                   random.choice(merchants), status=random.choice(["success", "success", "failed"]))

transactions_df = pd.DataFrame(transactions)

# ------------------------------------------------------------------
# SAVE
# ------------------------------------------------------------------
users_df.to_csv("../data/users.csv", index=False)
referrals_df.to_csv("../data/referrals.csv", index=False)
bonus_df.to_csv("../data/bonus_claims.csv", index=False)
transactions_df.to_csv("../data/transactions.csv", index=False)

print("Data generation complete.")
print(f"Users: {len(users_df)}  |  Fraud-ring users (ground truth, hidden from model): {users_df.is_synthetic_fraud_ring.sum()}")
print(f"Transactions: {len(transactions_df)}")
print(f"Referrals: {len(referrals_df)}")
print(f"Bonus claims: {len(bonus_df)}")
