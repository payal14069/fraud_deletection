"""
04_prepare_dashboard_data.py
------------------------------
Aggregates all analysis outputs into a single JSON payload consumed by
the static HTML dashboard (dashboard/index.html).
"""

import pandas as pd
import json

risk = pd.read_csv("../data/user_risk_scores.csv", parse_dates=[])
tx = pd.read_csv("../data/transactions.csv", parse_dates=["transaction_time"])
flagged_tx = pd.read_csv("../data/flagged_transactions.csv", parse_dates=["transaction_time"])
rule_summary = pd.read_csv("../data/rule_trigger_summary.csv")
threshold_df = pd.read_csv("../data/threshold_analysis.csv")
bonus = pd.read_csv("../data/bonus_claims.csv")
referrals = pd.read_csv("../data/referrals.csv")

payload = {}

# KPI cards
payload["kpis"] = {
    "total_users": int(len(risk)),
    "high_risk": int((risk.risk_score >= 70).sum()),
    "medium_risk": int(((risk.risk_score >= 40) & (risk.risk_score < 70)).sum()),
    "low_risk": int((risk.risk_score < 40).sum()),
    "total_transactions": int(len(tx)),
    "flagged_transactions": int(len(flagged_tx)),
    "flagged_tx_pct": round(len(flagged_tx) / len(tx) * 100, 2),
    "total_tx_volume": round(float(tx["amount"].sum()), 2),
    "flagged_tx_volume": round(float(flagged_tx["amount"].sum()), 2),
    "total_bonus_claims": int(len(bonus)),
    "total_referrals": int(len(referrals)),
    "recommended_threshold": 35,
    "model_recall_at_threshold": 1.0,
    "model_precision_at_threshold": 1.0,
}

# Risk band distribution
payload["risk_distribution"] = (
    risk["risk_band"].value_counts().rename_axis("band").reset_index(name="count").to_dict("records")
)

# Risk score histogram (binned)
bins = list(range(0, 105, 5))
risk["bin"] = pd.cut(risk["risk_score"], bins=bins, right=False)
hist = risk.groupby("bin", observed=True).size().reset_index(name="count")
payload["risk_histogram"] = {
    "labels": [f"{int(iv.left)}" for iv in hist["bin"]],
    "counts": hist["count"].tolist(),
}

# Rule trigger summary (bar chart)
payload["rule_triggers"] = rule_summary.to_dict("records")

# Transactions by hour (odd-hour pattern visualization)
tx["hour"] = tx["transaction_time"].dt.hour
hourly_all = tx.groupby("hour").size().reindex(range(24), fill_value=0)
hourly_flagged = flagged_tx.copy()
hourly_flagged["hour"] = pd.to_datetime(hourly_flagged["transaction_time"]).dt.hour
hourly_flagged_counts = hourly_flagged.groupby("hour").size().reindex(range(24), fill_value=0)
payload["hourly_pattern"] = {
    "hours": list(range(24)),
    "all_tx": hourly_all.tolist(),
    "flagged_tx": hourly_flagged_counts.tolist(),
}

# Threshold precision/recall tradeoff
payload["threshold_analysis"] = threshold_df.to_dict("records")

# Top 15 highest risk users (table)
top_risk_cols = ["user_id", "risk_score", "risk_band", "fake_account_score",
                  "suspicious_tx_count", "bonus_abuse_score", "referral_fraud_score",
                  "kyc_verified", "email_domain"]
payload["top_risk_users"] = risk.sort_values("risk_score", ascending=False)[top_risk_cols].head(15).to_dict("records")

# Fraud category breakdown (for donut)
payload["category_breakdown"] = [
    {"category": "Fake Accounts", "count": int(rule_summary[rule_summary.category == "Fake Account"]["users_triggered"].sum())},
    {"category": "Suspicious Transactions", "count": int(len(flagged_tx["user_id"].unique()) if len(flagged_tx) else 0)},
    {"category": "Bonus Abuse", "count": int(rule_summary[rule_summary.category == "Bonus Abuse"]["users_triggered"].sum())},
    {"category": "Referral Fraud", "count": int(rule_summary[rule_summary.rule == "flag_same_device_or_ip_referral"]["users_triggered"].sum())},
]

with open("../dashboard/data.json", "w") as f:
    json.dump(payload, f, indent=2, default=str)

print("Dashboard data payload written to ../dashboard/data.json")
print(json.dumps(payload["kpis"], indent=2))
