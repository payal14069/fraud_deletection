"""
03_fp_fn_threshold_analysis.py
--------------------------------
Evaluates the risk-scoring model against ground truth (synthetic fraud
ring labels) across a range of thresholds, quantifying the
false positive / false negative tradeoff, and recommends an
operating threshold.

Output: ../data/threshold_analysis.csv
"""

import pandas as pd
import numpy as np

risk = pd.read_csv("../data/user_risk_scores.csv")

thresholds = list(range(10, 96, 5))
rows = []
for t in thresholds:
    predicted_fraud = risk["risk_score"] >= t
    actual_fraud = risk["is_synthetic_fraud_ring"] == True

    tp = int((predicted_fraud & actual_fraud).sum())
    fp = int((predicted_fraud & ~actual_fraud).sum())
    fn = int((~predicted_fraud & actual_fraud).sum())
    tn = int((~predicted_fraud & ~actual_fraud).sum())

    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0
    fpr = fp / (fp + tn) if (fp + tn) else 0

    rows.append({
        "threshold": t, "true_positive": tp, "false_positive": fp,
        "false_negative": fn, "true_negative": tn,
        "precision": round(precision, 3), "recall": round(recall, 3),
        "f1_score": round(f1, 3), "false_positive_rate": round(fpr, 4),
        "customers_blocked_pct": round(predicted_fraud.mean() * 100, 2),
    })

df = pd.DataFrame(rows)
df.to_csv("../data/threshold_analysis.csv", index=False)

best_f1_row = df.loc[df["f1_score"].idxmax()]
print("Threshold analysis complete. Saved threshold_analysis.csv\n")
print(df.to_string(index=False))
print(f"\nRecommended threshold (best F1 balance): {int(best_f1_row.threshold)}  "
      f"(Precision={best_f1_row.precision}, Recall={best_f1_row.recall}, F1={best_f1_row.f1_score})")
