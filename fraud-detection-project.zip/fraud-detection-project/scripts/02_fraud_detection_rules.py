"""
02_fraud_detection_rules.py
----------------------------
Implements rule-based + statistical fraud detection logic across:
  1. Fake / suspicious account detection
  2. Suspicious transaction detection
  3. Bonus / promotional abuse detection
  4. Referral fraud detection
  5. Unusual behavior pattern detection
  6. Composite risk scoring (0-100) per user

Outputs:
  - ../data/user_risk_scores.csv       (final scored + flagged users)
  - ../data/flagged_transactions.csv
  - ../data/rule_trigger_summary.csv
"""

import pandas as pd
import numpy as np

pd.set_option("display.width", 140)

users = pd.read_csv("../data/users.csv", parse_dates=["signup_date"])
tx = pd.read_csv("../data/transactions.csv", parse_dates=["transaction_time"])
referrals = pd.read_csv("../data/referrals.csv", parse_dates=["referral_date"])
bonus = pd.read_csv("../data/bonus_claims.csv", parse_dates=["claim_date"])

DISPOSABLE_DOMAINS = ["mailinator.com", "10minutemail.com", "tempmail.com",
                       "guerrillamail.com", "yopmail.com", "trashmail.com"]

# ============================================================
# RULE 1: FAKE / SUSPICIOUS ACCOUNT DETECTION
# ============================================================
# 1a. Multiple accounts sharing the same device_id
device_counts = users.groupby("device_id")["user_id"].nunique().rename("accounts_per_device")
users = users.merge(device_counts, on="device_id", how="left")
users["flag_shared_device"] = users["accounts_per_device"] >= 3

# 1b. Multiple accounts sharing the same signup IP
ip_counts = users.groupby("signup_ip")["user_id"].nunique().rename("accounts_per_ip")
users = users.merge(ip_counts, on="signup_ip", how="left")
users["flag_shared_ip"] = users["accounts_per_ip"] >= 3

# 1c. Disposable / throwaway email domain
users["email_domain"] = users["email"].str.split("@").str[-1]
users["flag_disposable_email"] = users["email_domain"].isin(DISPOSABLE_DOMAINS)

# 1d. Not KYC verified
users["flag_no_kyc"] = ~users["kyc_verified"]

# 1e. Burst signups: many accounts created from the same device/IP within a tight time window
users_sorted = users.sort_values(["device_id", "signup_date"])
users_sorted["prev_signup"] = users_sorted.groupby("device_id")["signup_date"].shift(1)
users_sorted["gap_minutes"] = (users_sorted["signup_date"] - users_sorted["prev_signup"]).dt.total_seconds() / 60
burst_flags = users_sorted.groupby("user_id")["gap_minutes"].min().le(60).rename("flag_burst_signup")
users = users.merge(burst_flags, on="user_id", how="left")
users["flag_burst_signup"] = users["flag_burst_signup"].fillna(False)

FAKE_ACCOUNT_RULES = ["flag_shared_device", "flag_shared_ip", "flag_disposable_email",
                       "flag_no_kyc", "flag_burst_signup"]
users["fake_account_score"] = users[FAKE_ACCOUNT_RULES].sum(axis=1)

# ============================================================
# RULE 2: SUSPICIOUS TRANSACTION DETECTION
# ============================================================
tx["hour"] = tx["transaction_time"].dt.hour
tx["flag_odd_hour"] = tx["hour"].isin([1, 2, 3, 4])

# High-value transaction: > 95th percentile
high_val_threshold = tx["amount"].quantile(0.95)
tx["flag_high_amount"] = tx["amount"] > high_val_threshold

# Transaction velocity: >=4 transactions by same user within 30 minutes
tx_sorted = tx.sort_values(["user_id", "transaction_time"])
tx_sorted["prev_time"] = tx_sorted.groupby("user_id")["transaction_time"].shift(1)
tx_sorted["gap_min"] = (tx_sorted["transaction_time"] - tx_sorted["prev_time"]).dt.total_seconds() / 60
velocity_counts = tx_sorted.groupby("user_id").apply(
    lambda g: (g["gap_min"] < 10).sum()
).rename("rapid_tx_count")
tx = tx.merge(velocity_counts, on="user_id", how="left")
tx["flag_high_velocity"] = tx["rapid_tx_count"] >= 4

# New-account cash-out: withdrawal within 48h of signup, amount > threshold
tx = tx.merge(users[["user_id", "signup_date"]], on="user_id", how="left")
tx["hours_since_signup"] = (tx["transaction_time"] - tx["signup_date"]).dt.total_seconds() / 3600
tx["flag_new_account_cashout"] = (
    (tx["transaction_type"] == "withdrawal") &
    (tx["hours_since_signup"] <= 48) &
    (tx["amount"] > tx["amount"].quantile(0.7))
)

# Failed-then-success pattern (possible card testing) - repeated failed tx by same user same day
daily_fail_counts = tx[tx.status == "failed"].groupby(
    ["user_id", tx["transaction_time"].dt.date]
).size().rename("fail_count").reset_index()
frequent_fail_users = set(daily_fail_counts[daily_fail_counts.fail_count >= 3]["user_id"])
tx["flag_card_testing"] = tx["user_id"].isin(frequent_fail_users)

TX_RULES = ["flag_odd_hour", "flag_high_amount", "flag_high_velocity",
            "flag_new_account_cashout", "flag_card_testing"]
tx["suspicious_tx_score"] = tx[TX_RULES].sum(axis=1)
tx["is_suspicious_transaction"] = tx["suspicious_tx_score"] >= 2

flagged_tx = tx[tx["is_suspicious_transaction"]].copy()
flagged_tx.to_csv("../data/flagged_transactions.csv", index=False)

# Aggregate transaction-level suspicion back to user level
user_tx_agg = tx.groupby("user_id").agg(
    total_tx=("transaction_id", "count"),
    total_amount=("amount", "sum"),
    avg_amount=("amount", "mean"),
    suspicious_tx_count=("is_suspicious_transaction", "sum"),
    failed_tx_count=("status", lambda s: (s == "failed").sum()),
).reset_index()
user_tx_agg["suspicious_tx_ratio"] = (
    user_tx_agg["suspicious_tx_count"] / user_tx_agg["total_tx"]
).fillna(0)

# ============================================================
# RULE 3: BONUS / PROMOTIONAL ABUSE DETECTION
# ============================================================
bonus_per_device = bonus.groupby("device_id")["user_id"].nunique().rename("accounts_claiming_bonus_per_device")
bonus = bonus.merge(bonus_per_device, on="device_id", how="left")
bonus["flag_bonus_farming_device"] = bonus["accounts_claiming_bonus_per_device"] >= 3

multi_bonus_users = bonus.groupby("user_id")["claim_type"].apply(
    lambda s: s.nunique() > 1 or len(s) > 2
).rename("flag_multiple_bonus_claims")

bonus_summary = bonus.groupby("user_id").agg(
    total_bonus_claimed=("amount", "sum"),
    bonus_claim_count=("claim_id", "count"),
).reset_index()
bonus_summary = bonus_summary.merge(multi_bonus_users, on="user_id", how="left")
device_flag_per_user = bonus.groupby("user_id")["flag_bonus_farming_device"].max()
bonus_summary = bonus_summary.merge(device_flag_per_user, on="user_id", how="left")
bonus_summary["flag_multiple_bonus_claims"] = bonus_summary["flag_multiple_bonus_claims"].fillna(False)
bonus_summary["flag_bonus_farming_device"] = bonus_summary["flag_bonus_farming_device"].fillna(False)
bonus_summary["bonus_abuse_score"] = (
    bonus_summary["flag_multiple_bonus_claims"].astype(int) +
    bonus_summary["flag_bonus_farming_device"].astype(int)
)

# ============================================================
# RULE 4: REFERRAL FRAUD DETECTION
# ============================================================
ref_counts = referrals.groupby("referrer_id")["referee_id"].nunique().rename("referral_count")
referrals = referrals.merge(users[["user_id", "device_id", "signup_ip"]].rename(
    columns={"user_id": "referrer_id", "device_id": "referrer_device", "signup_ip": "referrer_ip"}),
    on="referrer_id", how="left")
referrals = referrals.merge(users[["user_id", "device_id", "signup_ip"]].rename(
    columns={"user_id": "referee_id", "device_id": "referee_device", "signup_ip": "referee_ip"}),
    on="referee_id", how="left")

# Same device or IP between referrer and referee -> strong fraud signal
referrals["flag_same_device_referral"] = referrals["referrer_device"] == referrals["referee_device"]
referrals["flag_same_ip_referral"] = referrals["referrer_ip"] == referrals["referee_ip"]

# Referral rings: referrer with abnormally high referral count in short time
referral_time_span = referrals.groupby("referrer_id")["referral_date"].agg(["min", "max", "count"])
referral_time_span["span_hours"] = (
    (referral_time_span["max"] - referral_time_span["min"]).dt.total_seconds() / 3600
).replace(0, 0.1)
referral_time_span["referrals_per_hour"] = referral_time_span["count"] / referral_time_span["span_hours"]
high_velocity_referrers = set(
    referral_time_span[(referral_time_span["count"] >= 3) &
                        (referral_time_span["referrals_per_hour"] > 0.3)].index
)

referral_fraud_by_user = referrals.groupby("referrer_id").agg(
    referral_count=("referee_id", "nunique"),
    same_device_referrals=("flag_same_device_referral", "sum"),
    same_ip_referrals=("flag_same_ip_referral", "sum"),
).reset_index().rename(columns={"referrer_id": "user_id"})
referral_fraud_by_user["flag_referral_ring"] = referral_fraud_by_user["user_id"].isin(high_velocity_referrers)
referral_fraud_by_user["referral_fraud_score"] = (
    (referral_fraud_by_user["same_device_referrals"] > 0).astype(int) +
    (referral_fraud_by_user["same_ip_referrals"] > 0).astype(int) +
    referral_fraud_by_user["flag_referral_ring"].astype(int)
)

# ============================================================
# COMPOSITE RISK SCORING (0-100)
# ============================================================
# Weighting rationale documented in README / methodology doc:
#   Account-level fraud signals: 35%
#   Transaction behavior:        35%
#   Bonus abuse:                 15%
#   Referral fraud:              15%

risk = users[["user_id", "fake_account_score"] + FAKE_ACCOUNT_RULES].copy()
risk = risk.merge(user_tx_agg, on="user_id", how="left")
risk = risk.merge(bonus_summary, on="user_id", how="left")
risk = risk.merge(referral_fraud_by_user, on="user_id", how="left")
risk = risk.merge(users[["user_id", "is_synthetic_fraud_ring", "ring_id", "kyc_verified", "email_domain"]],
                   on="user_id", how="left")

for col in ["total_tx", "suspicious_tx_count", "suspicious_tx_ratio", "bonus_abuse_score",
            "referral_fraud_score", "total_bonus_claimed", "bonus_claim_count", "referral_count"]:
    risk[col] = risk[col].fillna(0)

# Normalize each component to 0-1, then weight
risk["norm_account_score"] = (risk["fake_account_score"] / len(FAKE_ACCOUNT_RULES)).clip(0, 1)
risk["norm_tx_score"] = risk["suspicious_tx_ratio"].clip(0, 1) * 0.6 + \
                         (risk["suspicious_tx_count"] > 0).astype(int) * 0.4
risk["norm_tx_score"] = risk["norm_tx_score"].clip(0, 1)
risk["norm_bonus_score"] = (risk["bonus_abuse_score"] / 2).clip(0, 1)
risk["norm_referral_score"] = (risk["referral_fraud_score"] / 3).clip(0, 1)

risk["risk_score"] = (
    risk["norm_account_score"] * 35 +
    risk["norm_tx_score"] * 35 +
    risk["norm_bonus_score"] * 15 +
    risk["norm_referral_score"] * 15
).round(1)

def risk_band(score):
    if score >= 70:
        return "High Risk - Block/Review"
    elif score >= 40:
        return "Medium Risk - Monitor"
    else:
        return "Low Risk - Allow"

risk["risk_band"] = risk["risk_score"].apply(risk_band)
risk = risk.sort_values("risk_score", ascending=False)
risk.to_csv("../data/user_risk_scores.csv", index=False)

# ============================================================
# RULE TRIGGER SUMMARY (for dashboard + report)
# ============================================================
summary_rows = []
for rule in FAKE_ACCOUNT_RULES:
    summary_rows.append({"category": "Fake Account", "rule": rule, "users_triggered": int(users[rule].sum())})
summary_rows.append({"category": "Suspicious Transaction", "rule": "suspicious_transactions_flagged",
                      "users_triggered": int(flagged_tx["user_id"].nunique())})
summary_rows.append({"category": "Bonus Abuse", "rule": "flag_multiple_bonus_claims",
                      "users_triggered": int(bonus_summary["flag_multiple_bonus_claims"].sum())})
summary_rows.append({"category": "Bonus Abuse", "rule": "flag_bonus_farming_device",
                      "users_triggered": int(bonus_summary["flag_bonus_farming_device"].sum())})
summary_rows.append({"category": "Referral Fraud", "rule": "flag_same_device_or_ip_referral",
                      "users_triggered": int(((referral_fraud_by_user["same_device_referrals"] > 0) |
                                               (referral_fraud_by_user["same_ip_referrals"] > 0)).sum())})
summary_rows.append({"category": "Referral Fraud", "rule": "flag_referral_ring",
                      "users_triggered": int(referral_fraud_by_user["flag_referral_ring"].sum())})
pd.DataFrame(summary_rows).to_csv("../data/rule_trigger_summary.csv", index=False)

# ============================================================
# CONSOLE REPORT
# ============================================================
print("=" * 60)
print("FRAUD DETECTION — RULE EXECUTION SUMMARY")
print("=" * 60)
print(f"Total users analyzed: {len(users)}")
print(f"High risk users (score >= 70): {(risk.risk_score >= 70).sum()}")
print(f"Medium risk users (40-69): {((risk.risk_score >= 40) & (risk.risk_score < 70)).sum()}")
print(f"Low risk users (< 40): {(risk.risk_score < 40).sum()}")
print()
print("Ground truth check (synthetic fraud ring recall):")
caught = risk[(risk.is_synthetic_fraud_ring == True) & (risk.risk_score >= 40)]
total_ring = risk[risk.is_synthetic_fraud_ring == True]
print(f"  Fraud-ring users flagged (score>=40): {len(caught)} / {len(total_ring)} "
      f"({len(caught)/max(len(total_ring),1)*100:.1f}% recall)")
false_positives = risk[(risk.is_synthetic_fraud_ring == False) & (risk.risk_score >= 70)]
print(f"  Legit users incorrectly marked High Risk: {len(false_positives)} "
      f"({len(false_positives)/max((risk.is_synthetic_fraud_ring==False).sum(),1)*100:.2f}% of legit users)")
print()
print("Suspicious transactions flagged:", len(flagged_tx), f"/ {len(tx)}")
print("Saved: user_risk_scores.csv, flagged_transactions.csv, rule_trigger_summary.csv")
