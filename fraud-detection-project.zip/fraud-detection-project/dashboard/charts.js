// charts.js — renders all Plotly charts + tables from DASHBOARD_DATA (see data_embed.js)

const COLORS = {
  bg: "#0A0E13", panel: "#121821", border: "#232D3A",
  text: "#E7EDF2", muted: "#7C8B9C",
  brand: "#5B8CFF", high: "#FF5C5C", medium: "#F5B942", low: "#3DDC97", purple: "#B673FF"
};

const baseLayout = {
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor: "rgba(0,0,0,0)",
  font: { family: "-apple-system, Inter, sans-serif", color: COLORS.text, size: 11.5 },
  margin: { l: 44, r: 16, t: 10, b: 34 },
  xaxis: { gridcolor: COLORS.border, zerolinecolor: COLORS.border, linecolor: COLORS.border },
  yaxis: { gridcolor: COLORS.border, zerolinecolor: COLORS.border, linecolor: COLORS.border },
  showlegend: false,
};
const config = { displayModeBar: false, responsive: true };

// ---------- KPI cards ----------
const k = DASHBOARD_DATA.kpis;
const kpis = [
  { label: "Total Users", value: k.total_users.toLocaleString(), sub: "Analyzed in this run", cls: "brand" },
  { label: "High Risk", value: k.high_risk.toLocaleString(), sub: `${(k.high_risk/k.total_users*100).toFixed(1)}% of base — block/review`, cls: "high" },
  { label: "Medium Risk", value: k.medium_risk.toLocaleString(), sub: "Flagged for monitoring", cls: "medium" },
  { label: "Transactions Flagged", value: k.flagged_transactions.toLocaleString(), sub: `${k.flagged_tx_pct}% of ${k.total_transactions.toLocaleString()} total`, cls: "high" },
  { label: "Flagged Tx Volume", value: "$" + Math.round(k.flagged_tx_volume).toLocaleString(), sub: `of $${Math.round(k.total_tx_volume).toLocaleString()} total volume`, cls: "medium" },
  { label: "Operating Threshold", value: k.recommended_threshold, sub: `Precision ${Math.round(k.model_precision_at_threshold*100)}% · Recall ${Math.round(k.model_recall_at_threshold*100)}%`, cls: "low" },
];
document.getElementById("kpiGrid").innerHTML = kpis.map(item => `
  <div class="kpi ${item.cls}">
    <div class="label">${item.label}</div>
    <div class="value">${item.value}</div>
    <div class="sub">${item.sub}</div>
  </div>
`).join("");

// ---------- Pulse strip (signature element) ----------
const hp = DASHBOARD_DATA.hourly_pattern;
Plotly.newPlot("pulseChart", [
  {
    x: hp.hours, y: hp.all_tx, type: "scatter", mode: "lines",
    line: { color: COLORS.brand, width: 1.5, shape: "spline" },
    fill: "tozeroy", fillcolor: "rgba(91,140,255,0.08)",
    hovertemplate: "Hour %{x}:00 — %{y} tx<extra></extra>"
  },
  {
    x: hp.hours, y: hp.flagged_tx, type: "scatter", mode: "markers",
    marker: { color: COLORS.high, size: 6, symbol: "diamond" },
    hovertemplate: "Hour %{x}:00 — %{y} flagged<extra></extra>"
  }
], {
  ...baseLayout,
  margin: { l: 4, r: 4, t: 4, b: 18 },
  xaxis: { visible: false }, yaxis: { visible: false },
  height: 70,
}, config);

const spikeHours = hp.hours.filter((h, i) => hp.flagged_tx[i] > 50);
document.getElementById("pulseSpike").textContent =
  spikeHours.length ? `Spikes at ${spikeHours.map(h => h + ":00").join(", ")}` : "No abnormal spikes";

// ---------- Risk histogram ----------
const rh = DASHBOARD_DATA.risk_histogram;
Plotly.newPlot("histChart", [{
  x: rh.labels, y: rh.counts, type: "bar",
  marker: {
    color: rh.labels.map(v => +v >= 70 ? COLORS.high : (+v >= 40 ? COLORS.medium : COLORS.low))
  },
  hovertemplate: "Score %{x}+ — %{y} users<extra></extra>"
}], { ...baseLayout, xaxis: { ...baseLayout.xaxis, title: "Risk score" }, yaxis: { ...baseLayout.yaxis, title: "Users" } }, config);

// ---------- Donut: risk band split ----------
const rd = DASHBOARD_DATA.risk_distribution;
const bandColor = b => b.includes("High") ? COLORS.high : (b.includes("Medium") ? COLORS.medium : COLORS.low);
Plotly.newPlot("donutChart", [{
  labels: rd.map(r => r.band), values: rd.map(r => r.count),
  type: "pie", hole: 0.62,
  marker: { colors: rd.map(r => bandColor(r.band)), line: { color: COLORS.panel, width: 2 } },
  textfont: { color: COLORS.text, size: 11 },
  hovertemplate: "%{label}: %{value} (%{percent})<extra></extra>"
}], { ...baseLayout, showlegend: true, legend: { orientation: "h", y: -0.15, font: { size: 10.5 } } }, config);

// ---------- Hourly transaction pattern ----------
Plotly.newPlot("hourlyChart", [
  { x: hp.hours, y: hp.all_tx, type: "bar", name: "All transactions", marker: { color: "rgba(91,140,255,0.35)" } },
  { x: hp.hours, y: hp.flagged_tx, type: "bar", name: "Flagged", marker: { color: COLORS.high } },
], { ...baseLayout, barmode: "overlay", showlegend: true, legend: { orientation: "h", y: 1.15, font: { size: 10.5 } },
     xaxis: { ...baseLayout.xaxis, title: "Hour of day" }, yaxis: { ...baseLayout.yaxis, title: "Transactions" } }, config);

// ---------- Category breakdown ----------
const cb = DASHBOARD_DATA.category_breakdown;
Plotly.newPlot("categoryChart", [{
  x: cb.map(c => c.count), y: cb.map(c => c.category), type: "bar", orientation: "h",
  marker: { color: [COLORS.purple, COLORS.high, COLORS.medium, COLORS.brand] },
  hovertemplate: "%{y}: %{x} users<extra></extra>"
}], { ...baseLayout, margin: { l: 150, r: 20, t: 10, b: 34 }, xaxis: { ...baseLayout.xaxis, title: "Users flagged" } }, config);

// ---------- Threshold precision/recall ----------
const ta = DASHBOARD_DATA.threshold_analysis;
Plotly.newPlot("thresholdChart", [
  { x: ta.map(t => t.threshold), y: ta.map(t => t.precision), type: "scatter", mode: "lines+markers",
    name: "Precision", line: { color: COLORS.brand, width: 2 }, marker: { size: 5 } },
  { x: ta.map(t => t.threshold), y: ta.map(t => t.recall), type: "scatter", mode: "lines+markers",
    name: "Recall", line: { color: COLORS.low, width: 2 }, marker: { size: 5 } },
  { x: ta.map(t => t.threshold), y: ta.map(t => t.f1_score), type: "scatter", mode: "lines",
    name: "F1", line: { color: COLORS.medium, width: 1.5, dash: "dot" } },
], { ...baseLayout, showlegend: true, legend: { orientation: "h", y: 1.15, font: { size: 10.5 } },
     xaxis: { ...baseLayout.xaxis, title: "Risk threshold" }, yaxis: { ...baseLayout.yaxis, title: "Score", range: [0, 1.05] },
     shapes: [{ type: "line", x0: 35, x1: 35, y0: 0, y1: 1.05, line: { color: COLORS.high, width: 1, dash: "dash" } }],
     annotations: [{ x: 35, y: 1.02, text: "Selected = 35", showarrow: false, font: { color: COLORS.high, size: 10 } }]
   }, config);

// ---------- Rule trigger frequency ----------
const rt = DASHBOARD_DATA.rule_triggers;
const ruleColorMap = { "Fake Account": COLORS.purple, "Suspicious Transaction": COLORS.high,
                        "Bonus Abuse": COLORS.medium, "Referral Fraud": COLORS.brand };
Plotly.newPlot("ruleChart", [{
  x: rt.map(r => r.users_triggered), y: rt.map(r => r.rule.replace("flag_", "").replaceAll("_", " ")),
  type: "bar", orientation: "h",
  marker: { color: rt.map(r => ruleColorMap[r.category] || COLORS.brand) },
  hovertemplate: "%{y}: %{x} users<extra></extra>"
}], { ...baseLayout, margin: { l: 190, r: 20, t: 10, b: 34 }, xaxis: { ...baseLayout.xaxis, title: "Users triggered" } }, config);

// ---------- Top risk users table ----------
const tbody = document.getElementById("topTableBody");
tbody.innerHTML = DASHBOARD_DATA.top_risk_users.map(u => `
  <tr>
    <td>${u.user_id}</td>
    <td style="color:${u.risk_score >= 70 ? COLORS.high : (u.risk_score >= 40 ? COLORS.medium : COLORS.low)}">${u.risk_score}</td>
    <td><span class="badge high">${u.risk_band.split(" - ")[0]}</span></td>
    <td>${u.fake_account_score}/5</td>
    <td>${u.suspicious_tx_count}</td>
    <td>${u.bonus_abuse_score}/2</td>
    <td>${u.referral_fraud_score}/3</td>
    <td><span class="badge ${u.kyc_verified ? 'kyc-yes' : 'kyc-no'}">${u.kyc_verified ? 'Verified' : 'Not verified'}</span></td>
    <td>${u.email_domain}</td>
  </tr>
`).join("");
