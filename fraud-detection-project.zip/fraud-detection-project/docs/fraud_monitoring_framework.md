# Fraud Monitoring Framework

A framework for continuously tracking suspicious activity in production, beyond the one-off batch analysis in this repo.

## 1. Architecture Overview

```
┌─────────────┐   ┌──────────────────┐   ┌───────────────────┐   ┌─────────────┐
│ Event Stream│──▶│ Real-time Rule    │──▶│ Risk Scoring       │──▶│ Action Layer│
│ (signups,   │   │ Engine (stateless │   │ Service (stateful, │   │ (block/step-│
│ tx, claims) │   │ per-event rules)  │   │ aggregates history)│   │ up/allow)   │
└─────────────┘   └──────────────────┘   └───────────────────┘   └─────────────┘
                                                    │
                                                    ▼
                                        ┌────────────────────────┐
                                        │ Case Management Queue   │
                                        │ (analyst review, for    │
                                        │ Medium/High risk cases) │
                                        └────────────────────────┘
                                                    │
                                                    ▼
                                        ┌────────────────────────┐
                                        │ Feedback Loop           │
                                        │ (confirmed fraud/legit  │
                                        │ → retrain thresholds &  │
                                        │ eventually an ML model) │
                                        └────────────────────────┘
```

## 2. Two-speed monitoring

**Real-time (synchronous, sub-second):**
- Applied at signup and at transaction time.
- Device/IP fingerprint lookups, disposable-email checks, velocity counters (sliding window in Redis or similar) — all rules that need to block *before* an action completes (e.g. stop a cash-out mid-flight).
- Runs the same rule logic as `scripts/02_fraud_detection_rules.py`, ported to a streaming engine (e.g. Flink/Kafka Streams) or feature-flagged directly in the app backend.

**Batch (asynchronous, hourly/daily):**
- Recomputes the full composite risk score per user, including patterns that only emerge in aggregate (referral rings, bonus-farming device clusters, burst-signup cohorts) — these need a wider window of data than a single event.
- This repo's pipeline (scripts 01–04) is effectively a batch-mode dry run of this layer.

## 3. Alerting & Thresholds

| Trigger | Alert Route | SLA |
|---|---|---|
| Risk score ≥ 70 (High) | Auto-block + urgent review queue | Review within 2 hours |
| Risk score 40–69 (Medium) | Flag for enhanced monitoring, step-up verification | Review within 24 hours |
| Sudden spike in flagged transactions in a rolling 1h window (> 2x the 7-day rolling average) | Ops/on-call alert (Slack/PagerDuty) | Immediate — possible coordinated attack |
| A single device/IP crosses 3+ new accounts in 24h | Auto-hold new signups from that fingerprint pending review | Immediate |

The dashboard's "Transaction Pulse" panel is designed to make this last category of spike visually obvious to an analyst at a glance — analogous to a heart-rate monitor for the platform.

## 4. Reducing false positives / unnecessary customer friction

- **Multi-signal requirement**: no single rule alone blocks a user or transaction; escalation requires 2+ corroborating signals (see methodology.md §2). This is the single biggest lever for cutting false positives.
- **Step-up rather than hard-block for Medium risk**: ask for OTP/re-KYC instead of outright blocking — preserves legitimate customer experience while still adding friction for fraud.
- **Allow-list / trusted cohort exemptions**: long-tenured accounts with a clean transaction history should have rule sensitivity reduced (e.g. require a higher score to flag).
- **Human review before permanent action**: auto-block is reversible pending analyst review, not a permanent ban, unless corroborated by KYC/AML findings.

## 5. Continuous improvement loop

1. Every case resolved by an analyst (confirmed fraud / confirmed legitimate / inconclusive) is logged as ground truth.
2. Weekly: re-run the precision/recall/threshold analysis (`03_fp_fn_threshold_analysis.py`) against the accumulated real labels, not just the synthetic set.
3. Quarterly: revisit rule weights in the composite score, and evaluate whether accumulated labeled data (expect meaningful volume after ~3–6 months) justifies introducing a supervised ML layer (e.g. XGBoost on the same features) as a secondary score alongside the rules — not a replacement, since rules remain the explainable audit trail.
4. Track rule "decay" — a rule whose flagged users increasingly turn out to be false positives over time signals that fraud patterns have shifted and the rule needs retuning (e.g. fraud rings adapting to avoid known signatures).

## 6. Recommendations to reduce fraud while minimizing customer friction

- Prioritize KYC completion incentives — `flag_no_kyc` is one of the highest-signal, lowest-friction rules to act on (require KYC before large withdrawals rather than blocking signup outright).
- Rate-limit bonus claims per device/IP fingerprint at the product level, not just detection level — this closes the bonus-farming vector proactively rather than only catching it after the fact.
- Add a cooling-off period (e.g. 24–48h) before a referral bonus pays out, giving the referral-fraud rules a window to run before money moves.
- Monitor disposable-email domain lists as a maintained, updatable list (they change), not a hardcoded set.
