# Risk Scoring Methodology

## 1. Why a rule-based + weighted composite score (not a black-box ML model)

For a fraud detection system operating at a payment platform, **explainability is a hard requirement**, not a nice-to-have:

- Compliance and risk teams need to justify every block/review decision.
- Rules can be reasoned about, audited, and adjusted by a human analyst without retraining a model.
- A hybrid approach (deterministic rules → composite score → threshold band) gives interpretable output while still allowing statistical tuning (see false positive/negative analysis).

A supervised ML model (e.g. gradient boosting) is a natural **next iteration** once enough labeled real fraud outcomes accumulate — see `fraud_monitoring_framework.md` §5 for the recommended evolution path. It should sit *alongside* these rules as a secondary signal, not replace them outright, because rules remain the fallback explanation layer for regulators and disputes.

## 2. Rule categories and what each one detects

| Category | Rule | Signal it captures |
|---|---|---|
| Fake Account | `flag_shared_device` | 3+ accounts registered on the same device fingerprint |
| Fake Account | `flag_shared_ip` | 3+ accounts registered from the same signup IP |
| Fake Account | `flag_disposable_email` | Signup email uses a known disposable/temp-mail domain |
| Fake Account | `flag_no_kyc` | Account has not completed KYC verification |
| Fake Account | `flag_burst_signup` | Account created within 60 minutes of another account on the same device |
| Suspicious Transaction | `flag_odd_hour` | Transaction occurs between 1–4 AM local |
| Suspicious Transaction | `flag_high_amount` | Transaction amount exceeds the 95th percentile of all transactions |
| Suspicious Transaction | `flag_high_velocity` | 4+ transactions by the same user within a 10-minute window |
| Suspicious Transaction | `flag_new_account_cashout` | Withdrawal within 48h of signup, above the 70th percentile amount |
| Suspicious Transaction | `flag_card_testing` | 3+ failed transactions by the same user on the same day |
| Bonus Abuse | `flag_multiple_bonus_claims` | User claims more than one bonus type / more than 2 claims total |
| Bonus Abuse | `flag_bonus_farming_device` | 3+ distinct accounts claiming bonuses from the same device |
| Referral Fraud | `flag_same_device_referral` / `flag_same_ip_referral` | Referrer and referee share a device or IP (self-referral) |
| Referral Fraud | `flag_referral_ring` | Referrer generates 3+ referrals at an abnormally high velocity |

A transaction is only escalated to "suspicious" when **2 or more** transaction-level rules co-occur — this single-signal buffer is what keeps the false-positive rate low (see below), since any one signal alone (e.g. a large but legitimate payment) is common and not inherently fraudulent.

## 3. Composite Risk Score (0–100)

Each user receives four normalized sub-scores (0–1), then a weighted sum:

```
risk_score = (account_signal_norm   × 35)
           + (transaction_signal_norm × 35)
           + (bonus_signal_norm       × 15)
           + (referral_signal_norm    × 15)
```

**Why these weights?**
- **Account (35%) + Transaction (35%) = 70%** — these are the strongest, most direct fraud indicators (fake identity + confirmed bad behavior on the platform) and are weighted equally as co-primary signals.
- **Bonus abuse (15%) and Referral fraud (15%)** — real financial harm, but typically smaller-dollar and often a precursor/side effect of the account-level fraud already captured above, so they're weighted as secondary confirming signals rather than primary ones.
- Weights are configurable constants (`scripts/02_fraud_detection_rules.py`, composite scoring section) — a risk team should retune them periodically against real chargeback/dispute outcomes.

## 4. Risk Bands & Recommended Action

| Score | Band | Recommended Action |
|---|---|---|
| 70–100 | **High Risk** | Auto-block or route to manual review before allowing further transactions |
| 40–69 | **Medium Risk** | Allow, but flag for enhanced monitoring / step-up verification (e.g. re-KYC, OTP) |
| 0–39 | **Low Risk** | Allow, standard monitoring |

## 5. Threshold Selection

`scripts/03_fp_fn_threshold_analysis.py` sweeps thresholds 10–95 and computes precision, recall, F1, and false-positive rate against the (synthetic) ground truth. Results are in `data/threshold_analysis.csv`.

**Recommended operating threshold: 35** (used for the "flagged for review" cutoff in monitoring workflows, distinct from the stricter 70+ auto-block band above). At this threshold, on the synthetic validation set:
- Precision: 100% | Recall: 100% | F1: 1.00
- 0 legitimate users incorrectly blocked
- 4.8% of the user base flagged for review — a manageable review queue volume

In production with real, noisier data, expect precision to be lower than this synthetic result — the synthetic ground truth was purpose-built to be cleanly separable. Re-run this same threshold sweep against real labeled outcomes (confirmed fraud vs. confirmed legitimate disputes) before committing to a production threshold.
