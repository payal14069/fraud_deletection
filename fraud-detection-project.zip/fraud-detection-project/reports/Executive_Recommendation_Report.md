# Executive Recommendation Report
## Fraud & Anomaly Detection Challenge — Online Payment Platform

**Prepared for:** Technical Assessment Review
**Dataset:** Synthetic, 5,000 users / 25,662 transactions / 799 referrals / 4,669 bonus claims (see README for data note)

---

## 1. Summary

A rule-based fraud detection and risk-scoring system was built and validated across four fraud categories — fake accounts, suspicious transactions, bonus abuse, and referral fraud. At the recommended operating threshold (risk score ≥ 35), the system identified **100% of embedded fraudulent accounts with zero false positives** on legitimate users, flagging **4.8% of the user base** for review — a manageable, targeted review queue rather than a blunt mass-block.

## 2. Key Findings

| Metric | Value |
|---|---|
| Total users analyzed | 5,000 |
| High-risk users (score ≥ 70 — block/review) | 203 (4.1%) |
| Medium-risk users (40–69 — monitor) | 36 (0.7%) |
| Suspicious transactions flagged | 1,374 of 25,662 (5.4%) |
| Dollar volume in flagged transactions | $1,317,228 of $2,178,753 total (60.5%) |
| Accounts sharing a device fingerprint with others | 1,658 |
| Accounts sharing a signup IP with others | 1,853 |
| Accounts on disposable/temp-mail domains | 328 |
| Accounts without completed KYC | 567 |
| Devices exhibiting bonus-farming (3+ accounts) | 1,319 accounts implicated |
| Referrals with a self-referral signature (shared device/IP) | 199 |

**A critical insight from this analysis:** individual rules alone are noisy. 1,658 accounts share a device with another account — but the overwhelming majority of that is legitimate (shared family devices, shared office networks), not fraud. **Composite scoring across multiple co-occurring signals is what turns noisy single-rule flags into a precise, actionable list** — narrowing 1,600+ raw device-sharing flags down to a validated 239 confirmed high-risk accounts with no false positives. This is the core design principle behind the risk-scoring methodology (see `docs/methodology.md`).

The flagged transactions carry a disproportionate share of dollar volume (60.5% of total value in only 5.4% of transactions) — consistent with fraud rings favoring **fewer, larger cash-out transactions** rather than blending in with normal small-value activity. This pattern is visible on the dashboard's hourly transaction pulse, which shows flagged activity clustering heavily in the 1–4 AM and late-night windows, well outside normal usage hours.

## 3. False Positive / False Negative Tradeoff

A threshold sweep (`data/threshold_analysis.csv`, visualized on the dashboard) shows precision and recall stabilize at **100%/100%** from threshold 35 onward on the validation set, before recall begins degrading past threshold ~65 as the bar for "high risk" gets stricter. This gives the business a clear choice:

- **Threshold 35** (recommended for the review queue): maximizes fraud caught, still 0% false-positive rate on this data, ~4.8% of users flagged.
- **Threshold 70** (recommended for the stricter auto-block band): more conservative, only blocks the highest-confidence 4.1% of users outright, reserving the 35–69 band for softer friction (step-up verification) rather than a hard block.

In production, this tradeoff should be re-tuned against real confirmed-fraud outcomes rather than relied on at these exact synthetic numbers — see `docs/methodology.md` §5 and `docs/fraud_monitoring_framework.md` §5 for the recommended feedback loop.

## 4. Recommendations

1. **Adopt the two-tier threshold model**: score ≥ 70 → auto-block pending review; 40–69 → step-up verification (OTP/re-KYC) rather than an outright block, to minimize customer friction while still containing risk.
2. **Prioritize closing the KYC gap**: 567 unverified accounts is the single highest-leverage, lowest-friction fix — require KYC completion before any withdrawal above a modest threshold.
3. **Rate-limit bonus claims per device/IP at the product level**, not just at detection level, to proactively close the bonus-farming vector (1,319 accounts implicated) rather than only catching it after payout.
4. **Add a cooling-off window before referral payouts** (24–48h) so referral-fraud rules have time to run before money moves — currently referral fraud is only detectable after the fact.
5. **Operationalize continuous monitoring**: move from this one-off batch analysis to the two-speed (real-time + batch) framework detailed in `docs/fraud_monitoring_framework.md`, with a feedback loop that re-tunes thresholds against real analyst-confirmed outcomes on a recurring cadence.
6. **Treat this rule engine as the first iteration, not the final one**: as confirmed-fraud labels accumulate from analyst review, introduce a supervised ML model as a secondary, complementary signal — while keeping the rule-based system as the explainable audit trail required for compliance and customer disputes.

## 5. Next Steps

- Deploy the batch scoring pipeline (`scripts/02_fraud_detection_rules.py`) against a rolling window of real production data.
- Stand up the real-time rule layer for signup-time and transaction-time checks (Section 2 of the monitoring framework).
- Establish the analyst review queue and feedback-logging process so threshold tuning can move from synthetic validation to real-world validation within one review cycle.

---
*Full technical detail, all detection rule definitions, and the interactive dashboard are provided alongside this report — see `README.md` for the complete repository guide.*
