# Fraud & Anomaly Detection Challenge

**Data Analyst — Technical Assessment | Nexoraa Technosolve IT Services Pvt. Ltd.**

Detection framework for an online payment platform to identify fake accounts, suspicious transactions, bonus/promotional abuse, and referral fraud — including a composite risk-scoring model, threshold analysis, and an interactive monitoring dashboard.

> **Note on data:** No dataset was provided with the assignment, so a realistic **synthetic dataset** (5,000 users, 25,662 transactions, 799 referrals, 4,669 bonus claims) was generated with deliberately embedded fraud patterns — shared-device account rings, disposable-email signups, bonus farming, and referral rings — so the detection logic could be built and validated against a known ground truth. This is documented in `scripts/01_generate_data.py` and `docs/methodology.md`.

---

## 📁 Repository Structure

```
fraud-detection-project/
├── README.md                          ← you are here
├── data/
│   ├── users.csv                      ← synthetic user/account data
│   ├── transactions.csv               ← synthetic transaction data
│   ├── referrals.csv                  ← synthetic referral data
│   ├── bonus_claims.csv               ← synthetic bonus/promo claim data
│   ├── user_risk_scores.csv           ← OUTPUT: final scored & flagged users
│   ├── flagged_transactions.csv       ← OUTPUT: suspicious transactions
│   ├── rule_trigger_summary.csv       ← OUTPUT: rule-level trigger counts
│   └── threshold_analysis.csv         ← OUTPUT: precision/recall by threshold
├── scripts/
│   ├── 01_generate_data.py            ← synthetic data generator
│   ├── 02_fraud_detection_rules.py    ← ALL detection rules + risk scoring
│   ├── 03_fp_fn_threshold_analysis.py ← false positive/negative analysis
│   └── 04_prepare_dashboard_data.py   ← aggregates data for the dashboard
├── dashboard/
│   ├── index.html                     ← Fraud Detection Dashboard (open in browser)
│   ├── charts.js
│   ├── data_embed.js                  ← pre-computed data (dashboard is self-contained)
│   └── plotly.min.js                  ← vendored locally, works fully offline
├── reports/
│   └── Executive_Recommendation_Report.md
└── docs/
    ├── methodology.md                 ← risk scoring methodology & rule rationale
    └── fraud_monitoring_framework.md  ← ongoing monitoring framework design
```

---

## 🚀 Setup & Execution

### Requirements
```bash
pip install pandas numpy faker
```
(`plotly` is only needed if you want to regenerate charts programmatically — the dashboard itself vendors Plotly as a static JS file and needs no install.)

### Run the full pipeline
```bash
cd scripts
python3 01_generate_data.py               # generates data/*.csv
python3 02_fraud_detection_rules.py       # runs all detection rules + risk scoring
python3 03_fp_fn_threshold_analysis.py    # false positive / negative analysis
python3 04_prepare_dashboard_data.py      # builds dashboard/data_embed.js payload
```

### View the dashboard
Open `dashboard/index.html` directly in any browser — no server required, works offline.

---

## 🧠 Approach Summary

| # | Deliverable | Where |
|---|---|---|
| 1 | Fraud Detection Rules | `scripts/02_fraud_detection_rules.py` |
| 2 | Fake Account Detection Analysis | `02_fraud_detection_rules.py` → `RULE 1` |
| 3 | Suspicious Transaction Analysis | `02_fraud_detection_rules.py` → `RULE 2` |
| 4 | Bonus Abuse Detection | `02_fraud_detection_rules.py` → `RULE 3` |
| 5 | Referral Fraud Detection | `02_fraud_detection_rules.py` → `RULE 4` |
| 6 | False Positive vs False Negative Analysis | `scripts/03_fp_fn_threshold_analysis.py` |
| 7 | Risk Scoring Methodology | `docs/methodology.md` |
| 8 | Fraud Monitoring Framework | `docs/fraud_monitoring_framework.md` |
| 9 | Fraud Detection Dashboard | `dashboard/index.html` |
| 10 | Executive Recommendation Report | `reports/Executive_Recommendation_Report.md` |

### Detection logic at a glance

**Fake / suspicious accounts** — flags accounts sharing a device fingerprint or signup IP with 3+ other accounts, disposable email domains, missing KYC verification, and signup bursts (multiple accounts created from the same device within 60 minutes).

**Suspicious transactions** — flags odd-hour activity (1–4 AM), amounts above the 95th percentile, high-velocity bursts (4+ transactions within 10 minutes), new-account cash-outs (large withdrawal within 48h of signup), and repeated-failure patterns consistent with card testing. A transaction is marked suspicious when **2 or more** signals co-occur.

**Bonus abuse** — flags users claiming multiple bonus types, and devices from which 3+ distinct accounts have claimed bonuses (classic "bonus farming").

**Referral fraud** — flags referrer→referee pairs sharing a device or IP (self-referral), and referrers generating an abnormal referral velocity (referral rings).

**Composite risk score (0–100)** — weighted blend: Account signals 35% · Transaction behavior 35% · Bonus abuse 15% · Referral fraud 15%. Full rationale in `docs/methodology.md`.

### Validation against ground truth
Because the fraud patterns were embedded synthetically, we can objectively validate the rules: at the recommended threshold (score ≥ 35), the model achieves **100% recall and 100% precision** against the known fraud-ring accounts (239/239 caught, 0 false positives). Full precision/recall/F1 curve across thresholds 10–95 is in `data/threshold_analysis.csv` and visualized on the dashboard.

---

## ✍️ Author's Note
Every script is independently runnable and reproducible (fixed random seed = 42). Replace the CSVs in `data/` with real platform data (keeping the same column names) and the entire pipeline — rules, scoring, threshold analysis, and dashboard — will run unchanged.
